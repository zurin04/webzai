# VPS Manual Deployment Guide

Complete manual setup guide for deploying the crypto airdrop platform on Ubuntu/Debian VPS.

## Prerequisites

- Ubuntu 20.04+ or Debian 11+ VPS
- 1GB+ RAM, 20GB+ storage
- Root access or user with sudo privileges
- Domain name (optional but recommended)

## Step 1: System Updates and Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install essential packages
sudo apt install -y postgresql postgresql-contrib nginx git curl ufw

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Install SSL certificate tools (optional)
sudo apt install -y certbot python3-certbot-nginx
```

## Step 2: PostgreSQL Database Setup

```bash
# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql

# In PostgreSQL shell, run:
CREATE DATABASE crypto_airdrop_db;
CREATE USER airdrop_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop_db TO airdrop_user;
\q
```

## Step 3: Application Setup

```bash
# Create application directory
sudo mkdir -p /var/www/crypto-airdrop
cd /var/www/crypto-airdrop

# Clone your repository
sudo git clone https://github.com/yourusername/crypto-airdrop-platform.git .

# Set proper ownership
sudo chown -R $USER:$USER /var/www/crypto-airdrop

# Install dependencies
npm install

# Create production environment file
cp .env.example .env.production
```

Edit `.env.production` with your settings:
```bash
nano .env.production
```

Required environment variables:
```env
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://airdrop_user:your_secure_password@localhost:5432/crypto_airdrop_db
SESSION_SECRET=your_long_random_session_secret_here
```

## Step 4: Database Setup

```bash
# Push database schema
npm run db:push

# Seed initial data
npm run db:seed

# Build application
npm run build
```

## Step 5: PM2 Process Management

Create PM2 ecosystem file:
```bash
nano ecosystem.config.js
```

```javascript
module.exports = {
  apps: [{
    name: 'crypto-airdrop-platform',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
}
```

Start the application:
```bash
# Start with PM2
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
# Follow the instructions shown
```

## Step 6: Nginx Configuration

Create Nginx site configuration:
```bash
sudo nano /etc/nginx/sites-available/crypto-airdrop
```

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable the site:
```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

## Step 7: SSL Certificate (Optional)

```bash
# Install SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Test automatic renewal
sudo certbot renew --dry-run
```

## Step 8: Firewall Configuration

```bash
# Configure UFW firewall
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## Step 9: Verification

Check that everything is running:
```bash
# Check PM2 status
pm2 status

# Check application logs
pm2 logs crypto-airdrop-platform

# Check Nginx status
sudo systemctl status nginx

# Check PostgreSQL status
sudo systemctl status postgresql
```

Your application should now be accessible at:
- HTTP: `http://your-domain.com` or `http://your-server-ip`
- HTTPS: `https://your-domain.com` (if SSL configured)

## Default Login Credentials

After successful deployment, use these default credentials:
- **Admin User:** `admin` / `admin123`
- **Demo User:** `demo` / `demo123`

**Important:** Change these passwords immediately after first login.

## Maintenance Commands

```bash
# View application logs
pm2 logs crypto-airdrop-platform

# Restart application
pm2 restart crypto-airdrop-platform

# Update application
cd /var/www/crypto-airdrop
git pull origin main
npm install
npm run build
pm2 restart crypto-airdrop-platform

# Database backup
pg_dump crypto_airdrop_db > backup_$(date +%Y%m%d).sql

# Restore database
psql crypto_airdrop_db < backup_file.sql
```

## Troubleshooting

### Application won't start
```bash
# Check logs for errors
pm2 logs crypto-airdrop-platform --lines 50

# Check environment variables
pm2 env 0

# Restart with verbose logging
pm2 restart crypto-airdrop-platform --log-date-format="YYYY-MM-DD HH:mm:ss Z"
```

### Database connection issues
```bash
# Test database connection
psql -h localhost -U airdrop_user -d crypto_airdrop_db

# Check PostgreSQL status
sudo systemctl status postgresql

# View PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### Nginx issues
```bash
# Test Nginx configuration
sudo nginx -t

# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log

# Restart Nginx
sudo systemctl restart nginx
```

---

**Deployment Complete!** Your crypto airdrop platform is now running on your VPS.
```

```sql
CREATE DATABASE crypto_airdrop_db;
CREATE USER airdrop_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop_db TO airdrop_user;
GRANT ALL ON SCHEMA public TO airdrop_user;
ALTER USER airdrop_user CREATEDB;
\q
```

```bash
# Configure authentication
sudo nano /etc/postgresql/*/main/pg_hba.conf
```

Add this line after the postgres peer line:
```
local   crypto_airdrop_db    airdrop_user                     md5
```

```bash
# Restart PostgreSQL
sudo systemctl restart postgresql
```

### Step 3: Application Setup

```bash
# Create application directory
sudo mkdir -p /var/www/crypto-airdrop
sudo chown $USER:$USER /var/www/crypto-airdrop
cd /var/www/crypto-airdrop

# Clone repository
git clone https://github.com/your-username/crypto-airdrop-platform.git .

# Install dependencies
npm install
```

### Step 4: Environment Configuration

```bash
# Create production environment file
nano .env.production
```

```env
NODE_ENV=production
DATABASE_URL=postgresql://airdrop_user:your_secure_password@localhost:5432/crypto_airdrop_db
SESSION_SECRET=your_64_character_random_session_secret_here
PORT=5000
```

```bash
# Secure the environment file
chmod 600 .env.production

# Generate a secure session secret
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### Step 5: Database Schema and Data

```bash
# Set environment for production
export NODE_ENV=production

# Create database tables
npm run db:push

# Seed initial data (admin user, categories, sample airdrops)
npm run db:seed

# Build the application
npm run build
```

### Step 6: Process Management

```bash
# Create PM2 ecosystem file
nano ecosystem.config.js
```

```javascript
module.exports = {
  apps: [{
    name: 'crypto-airdrop-platform',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env_file: '.env.production',
    env: {
      NODE_ENV: 'production'
    }
  }]
}
```

```bash
# Start application
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
# Run the command that PM2 outputs
```

### Step 7: Nginx Reverse Proxy

```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/crypto-airdrop
```

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support for chat
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
}
```

```bash
# Enable site and remove default
sudo ln -s /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test and restart Nginx
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### Step 8: SSL Certificate (Optional)

```bash
# Install SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Test automatic renewal
sudo certbot renew --dry-run
```

### Step 9: Firewall Configuration

```bash
# Enable firewall
sudo ufw enable

# Allow necessary ports
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Check status
sudo ufw status
```

### Step 10: Backup and Maintenance Scripts

```bash
# Create scripts directory
sudo mkdir -p /opt/crypto-airdrop/scripts

# Create backup script
sudo nano /opt/crypto-airdrop/scripts/backup.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/opt/crypto-airdrop/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Database backup
PGPASSWORD='your_secure_password' pg_dump -U airdrop_user -h localhost crypto_airdrop_db > $BACKUP_DIR/db_backup_$DATE.sql

# Keep only last 7 days
find $BACKUP_DIR -name "db_backup_*.sql" -mtime +7 -delete

echo "Backup completed: $DATE"
```

```bash
# Create update script
sudo nano /opt/crypto-airdrop/scripts/update.sh
```

```bash
#!/bin/bash
cd /var/www/crypto-airdrop
git pull
npm install
npm run build
pm2 restart crypto-airdrop-platform
echo "Application updated successfully"
```

```bash
# Make scripts executable
sudo chmod +x /opt/crypto-airdrop/scripts/*.sh

# Setup daily backup (runs at 2 AM)
(crontab -l 2>/dev/null; echo "0 2 * * * /opt/crypto-airdrop/scripts/backup.sh") | crontab -
```

## Post-Installation

### Default Access Credentials
- **Admin User:** `admin` / `admin123`
- **Demo User:** `demo` / `demo123`

### Application URLs
- **With Domain:** `https://your-domain.com` (if SSL enabled) or `http://your-domain.com`
- **With IP:** `http://your-server-ip`

### Important Security Steps
1. **Change default passwords immediately after first login**
2. **Keep database credentials secure** (stored in `.env.production`)
3. **Update the application regularly** using the update script
4. **Monitor logs regularly** with PM2

## Management Commands

```bash
# Application Status
pm2 status
pm2 logs crypto-airdrop-platform

# Restart Application
pm2 restart crypto-airdrop-platform

# Update Application
/opt/crypto-airdrop/scripts/update.sh

# Database Backup
/opt/crypto-airdrop/scripts/backup.sh

# View System Status
sudo systemctl status nginx postgresql

# Check Application Health
curl http://localhost:5000/api/categories
```

## Troubleshooting

### Application Won't Start
```bash
# Check detailed logs
pm2 logs crypto-airdrop-platform --lines 50

# Check if port is in use
sudo lsof -i :5000

# Restart services
sudo systemctl restart postgresql
pm2 restart crypto-airdrop-platform
```

### Database Connection Issues
```bash
# Test database connection
sudo -u postgres psql -d crypto_airdrop_db -U airdrop_user

# Check PostgreSQL status
sudo systemctl status postgresql

# View PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-*-main.log
```

### Nginx Configuration Issues
```bash
# Test configuration
sudo nginx -t

# Check error logs
sudo tail -f /var/log/nginx/error.log

# Restart Nginx
sudo systemctl restart nginx
```

### SSL Certificate Issues
```bash
# Renew certificate
sudo certbot renew

# Check certificate status
sudo certbot certificates

# Test SSL configuration
openssl s_client -connect your-domain.com:443
```

## Platform Features

The deployed platform includes:

- **User Authentication:** Registration, login, password reset
- **Role Management:** Admin, Creator, Regular user roles
- **Airdrop Management:** Create, edit, view detailed airdrop guides
- **Real-time Chat:** WebSocket-powered community chat
- **Crypto Tracker:** Live cryptocurrency price tracking
- **Creator Applications:** System for users to apply for creator status
- **Newsletter System:** Email subscription management
- **Admin Dashboard:** Complete platform management
- **Mobile Responsive:** Optimized for all devices

## Security Features

- SSL/TLS encryption
- Firewall protection
- Security headers
- Password hashing
- Session management
- Input validation
- SQL injection prevention
- XSS protection

---

**Total manual setup time:** 30-45 minutes  
**Automated setup time:** 5-10 minutes  
**Production ready:** Yes