import { useEffect } from "react";
import { useCrypto } from "@/hooks/use-crypto";
import CryptoCard from "./crypto-card";
import { useToast } from "@/hooks/use-toast";

export default function CryptoTracker() {
  const { coins, isLoading, error, refetchCoins, lastUpdated } = useCrypto();
  const { toast } = useToast();

  useEffect(() => {
    // Auto-refresh every 60 seconds
    const interval = setInterval(() => {
      refetchCoins();
    }, 60000);

    return () => clearInterval(interval);
  }, [refetchCoins]);
  
  useEffect(() => {
    if (error) {
      toast({
        title: "Error fetching cryptocurrency data",
        description: error.message,
        variant: "destructive",
      });
    }
  }, [error, toast]);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(6)].map((_, index) => (
          <div key={index} className="bg-card rounded-xl p-4 shadow animate-pulse">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <div className="w-8 h-8 mr-3 rounded-full bg-muted"></div>
                <div>
                  <div className="h-4 bg-muted rounded w-24 mb-1"></div>
                  <div className="h-3 bg-muted rounded w-10"></div>
                </div>
              </div>
              <div className="h-4 bg-muted rounded w-8"></div>
            </div>
            <div className="flex justify-between items-end">
              <div className="h-6 bg-muted rounded w-24"></div>
              <div className="h-4 bg-muted rounded w-16"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {coins.slice(0, 6).map((coin) => (
          <CryptoCard key={coin.id} coin={coin} />
        ))}
      </div>
      
      {lastUpdated && (
        <div className="text-sm text-gray-400 mt-2 flex items-center justify-end">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Last updated: {new Date(lastUpdated).toLocaleTimeString()}
        </div>
      )}
    </>
  );
}
